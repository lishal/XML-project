<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "it_company";
	
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 

		$detail_sql = "SELECT * FROM c_details";
		$result_details = $conn->query($detail_sql);

		$dept_sql = "SELECT dep_id FROM department";
		$result_dept = $conn->query($dept_sql);

		$deptnam_sql = "SELECT dep_name FROM department";
		$result_deptname = $conn->query($deptnam_sql);

		$p_id = "SELECT ID FROM employee";
		$result_pid = $conn->query($p_id);

		$xml=new DomDocument('1.0');
		$xml->formatOutput=true;
		/*create element using createElement()
		append child to parent using appendChild()*/
		while($row = mysqli_fetch_assoc($result_details)) {
			$company=$xml->createElement("it_company");
			$xml->appendChild($company);
			
			$details=$xml->createElement("detail");
			$ceo=$xml->createElement("ceo");
			$company->appendChild($details);
			$company->appendChild($ceo);
			
			$name=$xml->createElement("name", $row["c_name"]);
			$add=$xml->createElement("c_address", $row["c_address"]);
			$num=$xml->createElement("t_number", $row["t_number"]);
			$url=$xml->createElement("url", $row["url"]);
			$logo=$xml->createElement("logo");
			$details->appendChild($name);
			$details->appendChild($add);
			$details->appendChild($num);
			$details->appendChild($url);
			$details->appendChild($logo);
			
			$ceodet=$xml->createElement("ceo_details");
			$proman=$xml->createElement("project_manager");
			$RD=$xml->createElement("resDep");
			$MK=$xml->createElement("marketing");
			$HD=$xml->createElement("human");
			
			$ceo->appendChild($ceodet);
			$ceo->appendChild($proman);
			$ceo->appendChild($RD);
			$ceo->appendChild($MK);
			$ceo->appendChild($HD);

			$ceoname=$xml->createElement("ceo_name","Saroj PD Bhari");
			$ceoaddress=$xml->createElement("ceo_address","Samakhushi,Kathmandu");
			$ceophone=$xml->createElement("ceo_phone","9857036642");

			$ceodet->appendchild($ceoname);
			$ceodet->appendchild($ceoaddress);
			$ceodet->appendchild($ceophone);
			
			$pmdet=$xml->createElement("pm_details");
			$MD=$xml->createElement("mobile");
			$WD=$xml->createElement("web");
			
			$proman->appendChild($pmdet);
			$proman->appendChild($MD);
			$proman->appendChild($WD);

			$pmname=$xml->createElement("pm_name","Lalita Bhari");
			$pmaddress=$xml->createElement("pm_address","Samakhushi,Kathmandu");
			$pmphone=$xml->createElement("pm_phone","9847058612");

			$pmdet->appendchild($pmname);
			$pmdet->appendchild($pmaddress);
			$pmdet->appendchild($pmphone);

			$datas =array();
			if(mysqli_num_rows($result_dept) > 0){
				while ($roww = mysqli_fetch_assoc($result_dept)) {
					$datas[] = $roww;
				}
			}
			$name_datas =array();
			if(mysqli_num_rows($result_deptname) > 0){
				while ($name = mysqli_fetch_assoc($result_deptname)) {
					$name_datas[] = $name;
				}
			}
			$person_id =array();
			if(mysqli_num_rows($result_pid) > 0){
				while ($per_id = mysqli_fetch_assoc($result_pid)) {
					$person_id[] = $per_id;
				}
			}
			//FOR MOBILE DEPARTMENT
			foreach ($datas[0] as $data) {
				$dep1=$xml->createElement("dep1");
				$dep1->setAttribute("dep_ID",$data);
				$MD->appendChild($dep1);
				foreach ($name_datas[0] as $dep_name) {
					$dname1=$xml->createElement("d_name1",$dep_name);
					$perdet1=$xml->createElement("person_details1");
					$dep1->appendChild($dname1);
					$dep1->appendChild($perdet1);
					foreach ($person_id[0] as $Person) {
						$emp = "SELECT * FROM employee where ID='$Person'";
						$emp_details = $conn->query($emp);
						$emp_det = mysqli_fetch_assoc($emp_details);
						$p=$xml->createElement("Person");
						$p->setAttribute("ID",$Person);
						$p->setAttribute("sex",$emp_det["sex"]);
						$perdet1->appendChild($p);

						$fname=$xml->createElement("first", $emp_det["fname"]);
						$lname=$xml->createElement("last", $emp_det["lname"]);
						$address=$xml->createElement("address");
						$city=$xml->createElement("city", $emp_det["city"]);
						$street=$xml->createElement("street", $emp_det["street"]);
						$phone=$xml->createElement("phone", $emp_det["phone"]);
						$email=$xml->createElement("email", $emp_det["email"]);
						$salary=$xml->createElement("Salary", $emp_det["salary"]);
						
						$p->appendChild($fname);
						$p->appendChild($lname);
						$p->appendChild($address);
						$address->appendchild($city);
						$address->appendchild($street);
						$address->appendchild($phone);
						$address->appendchild($email);
						$p->appendChild($salary);
						
					}
					foreach ($person_id[1] as $Person) {
						$emp = "SELECT * FROM employee where ID='$Person'";
						$emp_details = $conn->query($emp);
						$emp_det = mysqli_fetch_assoc($emp_details);
						$p=$xml->createElement("Person");
						$p->setAttribute("ID",$Person);
						$p->setAttribute("sex",$emp_det["sex"]);
						$perdet1->appendChild($p);

						$fname=$xml->createElement("first", $emp_det["fname"]);
						$lname=$xml->createElement("last", $emp_det["lname"]);
						$address=$xml->createElement("address");
						$city=$xml->createElement("city", $emp_det["city"]);
						$street=$xml->createElement("street", $emp_det["street"]);
						$phone=$xml->createElement("phone", $emp_det["phone"]);
						$email=$xml->createElement("email", $emp_det["email"]);
						$salary=$xml->createElement("Salary", $emp_det["salary"]);
						
						$p->appendChild($fname);
						$p->appendChild($lname);
						$p->appendChild($address);
						$address->appendchild($city);
						$address->appendchild($street);
						$address->appendchild($phone);
						$address->appendchild($email);
						$p->appendChild($salary);
					}
					foreach ($person_id[2] as $Person) {
						$emp = "SELECT * FROM employee where ID='$Person'";
						$emp_details = $conn->query($emp);
						$emp_det = mysqli_fetch_assoc($emp_details);
						$p=$xml->createElement("Person");
						$p->setAttribute("ID",$Person);
						$p->setAttribute("sex",$emp_det["sex"]);
						$perdet1->appendChild($p);

						$fname=$xml->createElement("first", $emp_det["fname"]);
						$lname=$xml->createElement("last", $emp_det["lname"]);
						$address=$xml->createElement("address");
						$city=$xml->createElement("city", $emp_det["city"]);
						$street=$xml->createElement("street", $emp_det["street"]);
						$phone=$xml->createElement("phone", $emp_det["phone"]);
						$email=$xml->createElement("email", $emp_det["email"]);
						$salary=$xml->createElement("Salary", $emp_det["salary"]);
						
						$p->appendChild($fname);
						$p->appendChild($lname);
						$p->appendChild($address);
						$address->appendchild($city);
						$address->appendchild($street);
						$address->appendchild($phone);
						$address->appendchild($email);
						$p->appendChild($salary);
					}
				}
			}
			//For WEB DEPARTMENT
			foreach ($datas[1] as $data) {
				$dep2=$xml->createElement("dep2");
				$dep2->setAttribute("dep_ID",$data);
				$WD->appendChild($dep2);
				foreach ($name_datas[1] as $dep_name) {
					$dname2=$xml->createElement("d_name2",$dep_name);
					$dep2->appendChild($dname2);
					$perdet2=$xml->createElement("person_details2");
					$dep2->appendChild($perdet2);
					foreach ($person_id[3] as $Person) {
						$emp = "SELECT * FROM employee where ID='$Person'";
						$emp_details = $conn->query($emp);
						$emp_det = mysqli_fetch_assoc($emp_details);
						$p=$xml->createElement("Person");
						$p->setAttribute("ID",$Person);
						$p->setAttribute("sex",$emp_det["sex"]);
						$perdet2->appendChild($p);

						$fname=$xml->createElement("first", $emp_det["fname"]);
						$lname=$xml->createElement("last", $emp_det["lname"]);
						$address=$xml->createElement("address");
						$city=$xml->createElement("city", $emp_det["city"]);
						$street=$xml->createElement("street", $emp_det["street"]);
						$phone=$xml->createElement("phone", $emp_det["phone"]);
						$email=$xml->createElement("email", $emp_det["email"]);
						$salary=$xml->createElement("Salary", $emp_det["salary"]);
						
						$p->appendChild($fname);
						$p->appendChild($lname);
						$p->appendChild($address);
						$address->appendchild($city);
						$address->appendchild($street);
						$address->appendchild($phone);
						$address->appendchild($email);
						$p->appendChild($salary);
					}
					foreach ($person_id[4] as $Person) {
						$emp = "SELECT * FROM employee where ID='$Person'";
						$emp_details = $conn->query($emp);
						$emp_det = mysqli_fetch_assoc($emp_details);
						$p=$xml->createElement("Person");
						$p->setAttribute("ID",$Person);
						$p->setAttribute("sex",$emp_det["sex"]);
						$perdet2->appendChild($p);

						$fname=$xml->createElement("first", $emp_det["fname"]);
						$lname=$xml->createElement("last", $emp_det["lname"]);
						$address=$xml->createElement("address");
						$city=$xml->createElement("city", $emp_det["city"]);
						$street=$xml->createElement("street", $emp_det["street"]);
						$phone=$xml->createElement("phone", $emp_det["phone"]);
						$email=$xml->createElement("email", $emp_det["email"]);
						$salary=$xml->createElement("Salary", $emp_det["salary"]);
						
						$p->appendChild($fname);
						$p->appendChild($lname);
						$p->appendChild($address);
						$address->appendchild($city);
						$address->appendchild($street);
						$address->appendchild($phone);
						$address->appendchild($email);
						$p->appendChild($salary);
					}
					foreach ($person_id[5] as $Person) {
						$emp = "SELECT * FROM employee where ID='$Person'";
						$emp_details = $conn->query($emp);
						$emp_det = mysqli_fetch_assoc($emp_details);
						$p=$xml->createElement("Person");
						$p->setAttribute("ID",$Person);
						$p->setAttribute("sex",$emp_det["sex"]);
						$perdet2->appendChild($p);

						$fname=$xml->createElement("first", $emp_det["fname"]);
						$lname=$xml->createElement("last", $emp_det["lname"]);
						$address=$xml->createElement("address");
						$city=$xml->createElement("city", $emp_det["city"]);
						$street=$xml->createElement("street", $emp_det["street"]);
						$phone=$xml->createElement("phone", $emp_det["phone"]);
						$email=$xml->createElement("email", $emp_det["email"]);
						$salary=$xml->createElement("Salary", $emp_det["salary"]);
						
						$p->appendChild($fname);
						$p->appendChild($lname);
						$p->appendChild($address);
						$address->appendchild($city);
						$address->appendchild($street);
						$address->appendchild($phone);
						$address->appendchild($email);
						$p->appendChild($salary);
					}
				}
			}
			//For Research and development Department
			foreach ($datas[2] as $data) {
				$dep3=$xml->createElement("dep3");
				$dep3->setAttribute("dep_ID",$data);
				$RD->appendChild($dep3);
				foreach ($name_datas[2] as $dep_name) {
					$dname3=$xml->createElement("d_name3",$dep_name."ent");
					$dep3->appendChild($dname3);
					$perdet3=$xml->createElement("person_details3");
					$dep3->appendChild($perdet3);
					foreach ($person_id[6] as $Person) {
						$emp = "SELECT * FROM employee where ID='$Person'";
						$emp_details = $conn->query($emp);
						$emp_det = mysqli_fetch_assoc($emp_details);
						$p=$xml->createElement("Person");
						$p->setAttribute("ID",$Person);
						$p->setAttribute("sex",$emp_det["sex"]);
						$perdet3->appendChild($p);

						$fname=$xml->createElement("first", $emp_det["fname"]);
						$lname=$xml->createElement("last", $emp_det["lname"]);
						$address=$xml->createElement("address");
						$city=$xml->createElement("city", $emp_det["city"]);
						$street=$xml->createElement("street", $emp_det["street"]);
						$phone=$xml->createElement("phone", $emp_det["phone"]);
						$email=$xml->createElement("email", $emp_det["email"]);
						$salary=$xml->createElement("Salary", $emp_det["salary"]);
						
						$p->appendChild($fname);
						$p->appendChild($lname);
						$p->appendChild($address);
						$address->appendchild($city);
						$address->appendchild($street);
						$address->appendchild($phone);
						$address->appendchild($email);
						$p->appendChild($salary);
					}	
					foreach ($person_id[7] as $Person) {
						$emp = "SELECT * FROM employee where ID='$Person'";
						$emp_details = $conn->query($emp);
						$emp_det = mysqli_fetch_assoc($emp_details);
						$p=$xml->createElement("Person");
						$p->setAttribute("ID",$Person);
						$p->setAttribute("sex",$emp_det["sex"]);
						$perdet3->appendChild($p);

						$fname=$xml->createElement("first", $emp_det["fname"]);
						$lname=$xml->createElement("last", $emp_det["lname"]);
						$address=$xml->createElement("address");
						$city=$xml->createElement("city", $emp_det["city"]);
						$street=$xml->createElement("street", $emp_det["street"]);
						$phone=$xml->createElement("phone", $emp_det["phone"]);
						$email=$xml->createElement("email", $emp_det["email"]);
						$salary=$xml->createElement("Salary", $emp_det["salary"]);
						
						$p->appendChild($fname);
						$p->appendChild($lname);
						$p->appendChild($address);
						$address->appendchild($city);
						$address->appendchild($street);
						$address->appendchild($phone);
						$address->appendchild($email);
						$p->appendChild($salary);
					}
					foreach ($person_id[8] as $Person) {
						$emp = "SELECT * FROM employee where ID='$Person'";
						$emp_details = $conn->query($emp);
						$emp_det = mysqli_fetch_assoc($emp_details);
						$p=$xml->createElement("Person");
						$p->setAttribute("ID",$Person);
						$p->setAttribute("sex",$emp_det["sex"]);
						$perdet3->appendChild($p);

						$fname=$xml->createElement("first", $emp_det["fname"]);
						$lname=$xml->createElement("last", $emp_det["lname"]);
						$address=$xml->createElement("address");
						$city=$xml->createElement("city", $emp_det["city"]);
						$street=$xml->createElement("street", $emp_det["street"]);
						$phone=$xml->createElement("phone", $emp_det["phone"]);
						$email=$xml->createElement("email", $emp_det["email"]);
						$salary=$xml->createElement("Salary", $emp_det["salary"]);
						
						$p->appendChild($fname);
						$p->appendChild($lname);
						$p->appendChild($address);
						$address->appendchild($city);
						$address->appendchild($street);
						$address->appendchild($phone);
						$address->appendchild($email);
						$p->appendChild($salary);
					}
				}
			}
			//FOR Marketing department
			foreach ($datas[3] as $data) {
				$dep4=$xml->createElement("dep4");
				$dep4->setAttribute("dep_ID",$data);
				$MK->appendChild($dep4);
				foreach ($name_datas[3] as $dep_name) {
					$dname4=$xml->createElement("d_name4",$dep_name);
					$dep4->appendChild($dname4);
					$perdet4=$xml->createElement("person_details4");
					$dep4->appendChild($perdet4);
					foreach ($person_id[9] as $Person) {
						$emp = "SELECT * FROM employee where ID='$Person'";
						$emp_details = $conn->query($emp);
						$emp_det = mysqli_fetch_assoc($emp_details);
						$p=$xml->createElement("Person");
						$p->setAttribute("ID",$Person);
						$p->setAttribute("sex",$emp_det["sex"]);
						$perdet4->appendChild($p);

						$fname=$xml->createElement("first", $emp_det["fname"]);
						$lname=$xml->createElement("last", $emp_det["lname"]);
						$address=$xml->createElement("address");
						$city=$xml->createElement("city", $emp_det["city"]);
						$street=$xml->createElement("street", $emp_det["street"]);
						$phone=$xml->createElement("phone", $emp_det["phone"]);
						$email=$xml->createElement("email", $emp_det["email"]);
						$salary=$xml->createElement("Salary", $emp_det["salary"]);
						
						$p->appendChild($fname);
						$p->appendChild($lname);
						$p->appendChild($address);
						$address->appendchild($city);
						$address->appendchild($street);
						$address->appendchild($phone);
						$address->appendchild($email);
						$p->appendChild($salary);
					}
					foreach ($person_id[10] as $Person) {
						$emp = "SELECT * FROM employee where ID='$Person'";
						$emp_details = $conn->query($emp);
						$emp_det = mysqli_fetch_assoc($emp_details);
						$p=$xml->createElement("Person");
						$p->setAttribute("ID",$Person);
						$p->setAttribute("sex",$emp_det["sex"]);
						$perdet4->appendChild($p);

						$fname=$xml->createElement("first", $emp_det["fname"]);
						$lname=$xml->createElement("last", $emp_det["lname"]);
						$address=$xml->createElement("address");
						$city=$xml->createElement("city", $emp_det["city"]);
						$street=$xml->createElement("street", $emp_det["street"]);
						$phone=$xml->createElement("phone", $emp_det["phone"]);
						$email=$xml->createElement("email", $emp_det["email"]);
						$salary=$xml->createElement("Salary", $emp_det["salary"]);
						
						$p->appendChild($fname);
						$p->appendChild($lname);
						$p->appendChild($address);
						$address->appendchild($city);
						$address->appendchild($street);
						$address->appendchild($phone);
						$address->appendchild($email);
						$p->appendChild($salary);
					}
					foreach ($person_id[11] as $Person) {
						$emp = "SELECT * FROM employee where ID='$Person'";
						$emp_details = $conn->query($emp);
						$emp_det = mysqli_fetch_assoc($emp_details);
						$p=$xml->createElement("Person");
						$p->setAttribute("ID",$Person);
						$p->setAttribute("sex",$emp_det["sex"]);
						$perdet4->appendChild($p);

						$fname=$xml->createElement("first", $emp_det["fname"]);
						$lname=$xml->createElement("last", $emp_det["lname"]);
						$address=$xml->createElement("address");
						$city=$xml->createElement("city", $emp_det["city"]);
						$street=$xml->createElement("street", $emp_det["street"]);
						$phone=$xml->createElement("phone", $emp_det["phone"]);
						$email=$xml->createElement("email", $emp_det["email"]);
						$salary=$xml->createElement("Salary", $emp_det["salary"]);
						
						$p->appendChild($fname);
						$p->appendChild($lname);
						$p->appendChild($address);
						$address->appendchild($city);
						$address->appendchild($street);
						$address->appendchild($phone);
						$address->appendchild($email);
						$p->appendChild($salary);
					}
				}
			}
			//For Human Resource Department
			foreach ($datas[4] as $data) {
				$dep5=$xml->createElement("dep5");
				$dep5->setAttribute("dep_ID",$data);
				$HD->appendChild($dep5);
				foreach ($name_datas[4] as $dep_name) {
					$dname5=$xml->createElement("d_name5",$dep_name);
					$dep5->appendChild($dname5);
					$perdet5=$xml->createElement("person_details5");
					$dep5->appendChild($perdet5);
					foreach ($person_id[12] as $Person) {
						$emp = "SELECT * FROM employee where ID='$Person'";
						$emp_details = $conn->query($emp);
						$emp_det = mysqli_fetch_assoc($emp_details);
						$p=$xml->createElement("Person");
						$p->setAttribute("ID",$Person);
						$p->setAttribute("sex",$emp_det["sex"]);
						$perdet5->appendChild($p);

						$fname=$xml->createElement("first", $emp_det["fname"]);
						$lname=$xml->createElement("last", $emp_det["lname"]);
						$address=$xml->createElement("address");
						$city=$xml->createElement("city", $emp_det["city"]);
						$street=$xml->createElement("street", $emp_det["street"]);
						$phone=$xml->createElement("phone", $emp_det["phone"]);
						$email=$xml->createElement("email", $emp_det["email"]);
						$salary=$xml->createElement("Salary", $emp_det["salary"]);
						
						$p->appendChild($fname);
						$p->appendChild($lname);
						$p->appendChild($address);
						$address->appendchild($city);
						$address->appendchild($street);
						$address->appendchild($phone);
						$address->appendchild($email);
						$p->appendChild($salary);
					}
					foreach ($person_id[13] as $Person) {
						$emp = "SELECT * FROM employee where ID='$Person'";
						$emp_details = $conn->query($emp);
						$emp_det = mysqli_fetch_assoc($emp_details);
						$p=$xml->createElement("Person");
						$p->setAttribute("ID",$Person);
						$p->setAttribute("sex",$emp_det["sex"]);
						$perdet5->appendChild($p);

						$fname=$xml->createElement("first", $emp_det["fname"]);
						$lname=$xml->createElement("last", $emp_det["lname"]);
						$address=$xml->createElement("address");
						$city=$xml->createElement("city", $emp_det["city"]);
						$street=$xml->createElement("street", $emp_det["street"]);
						$phone=$xml->createElement("phone", $emp_det["phone"]);
						$email=$xml->createElement("email", $emp_det["email"]);
						$salary=$xml->createElement("Salary", $emp_det["salary"]);
						
						$p->appendChild($fname);
						$p->appendChild($lname);
						$p->appendChild($address);
						$address->appendchild($city);
						$address->appendchild($street);
						$address->appendchild($phone);
						$address->appendchild($email);
						$p->appendChild($salary);
					}
					foreach ($person_id[14] as $Person) {
						$emp = "SELECT * FROM employee where ID='$Person'";
						$emp_details = $conn->query($emp);
						$emp_det = mysqli_fetch_assoc($emp_details);
						$p=$xml->createElement("Person");
						$p->setAttribute("ID",$Person);
						$p->setAttribute("sex",$emp_det["sex"]);
						$perdet5->appendChild($p);

						$fname=$xml->createElement("first", $emp_det["fname"]);
						$lname=$xml->createElement("last", $emp_det["lname"]);
						$address=$xml->createElement("address");
						$city=$xml->createElement("city", $emp_det["city"]);
						$street=$xml->createElement("street", $emp_det["street"]);
						$phone=$xml->createElement("phone", $emp_det["phone"]);
						$email=$xml->createElement("email", $emp_det["email"]);
						$salary=$xml->createElement("Salary", $emp_det["salary"]);
						
						$p->appendChild($fname);
						$p->appendChild($lname);
						$p->appendChild($address);
						$address->appendchild($city);
						$address->appendchild($street);
						$address->appendchild($phone);
						$address->appendchild($email);
						$p->appendChild($salary);
					}
				}
			}
		}

		echo "<xmp>".$xml->saveXML()."</xmp>";
		$xml->save('catalog_17030953.xml');
		//Save XML as a file
?>